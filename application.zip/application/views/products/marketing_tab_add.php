<div class="complete-level">
    <h5>COMPLETE LEVEL</h5>
    <div class="inline-block complete-level-ul"> 
        <ul>
            <li class="active">
                <span></span>
                <span>PART 1</span>
            </li>
            <li>
                <span></span>
                <span>PART 2</span>
            </li>
            <li>
                <span></span>
                <span>PART 3</span>
            </li>
            <li>
                <span></span>
                <span>PART 4</span>
            </li>
            <li>
                <span></span>
                <span>PART 5</span>
            </li>
        </ul>
    </div>
    <div class="inline-block complete-level-action">
        <h1> 0% </h1>
    </div>
</div>

<div class="row">
    <div class="col-sm-12">
            <div class="box-main-scroll">   
              <form class="form" style="margin-bottom: 0;" method="post" action="#">
                <div class="box col-sm-12">
                    <div class="box-header gray-bg">
                        PART - 1 
                    </div>
                    <div class="box-content">
                        <h5>PRODUCT TITLE: Brand, product and sub brand, name and specification, size in KG and dimensions in cm.</h5>
                        <div class="row">
                            <div class="col-md-1">
                                
                            </div>
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>EN</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <input class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');">
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>FR</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <input class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');">
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <h5>3 HIGHLIGHTS (60 charaters)</h5>
                        <div class="row">
                            <div class="col-md-1">
                                1
                            </div>
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>EN</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <input class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');">
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>FR</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <input class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');">
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-1">
                                2
                            </div>
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>EN</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <input class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');">
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>FR</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <input class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');">
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-1">
                                3
                            </div>
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>EN</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <input class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');">
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>FR</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <input class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');">
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                            </div>
                        </div>
                         
                        <hr>
                        <h5>IN PARAGRAPH HIGHLIGHT (200 charaters)</h5>
                        <div class="row">
                            <div class="col-md-1">
                                
                            </div>
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>EN</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <input class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');">
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>FR</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <input class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');">
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                            </div>
                        </div>

                        <hr>
                        <h5>PRODUCT INTRODUCTION (800 charaters)</h5>
                        <div class="row">
                            <div class="col-md-1">
                                
                            </div>
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>EN</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <textarea class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');"></textarea>
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>FR</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <textarea class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');"></textarea>
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                            </div>

                            <div class="col-sm-8 col-sm-offset-0">
                                <div class='form-group col-sm-6 text-left'>
                                        <div class='controls'>
                                            <label class='control-label check-box-margin'>
                                                <input type="checkbox" name="" id=""> <span>PART 1 COMPLETED (25%)</span>
                                            </label>
                                        </div>    
                                    </div>
                                
                                <div class='form-group pull-right'>
                                    <div class='controls'>
                                        <input type="hidden" name="" id="" value="">
                                        <a class="btn btn-success" onclick="validate_admin_part_2()" >
                                            <i class='icon-save'></i> Save
                                        </a>
                                        <a href="" class="btn btn-default" >Cancel</a>
                                    </div>
                                </div>
                            </div>          
                        </div>
                    </div> <!-- END of box-content -->
                </div>
              </form>
              <!-- End of part1 -->  
                <!-- Strat of part -2  -->
               <form class="form" style="margin-bottom: 0;" method="post" action="#">
                <div class="box col-sm-12">
                    <div class="box-header gray-bg">
                        PART 2 SELLING POINTS
                    </div>
                    <div class="box-content">
                        
                        <h5>SELLING POINTS (60 charaters for the tittle and 300 for the body)</h5>
                        <!-- row SELLING POINTS block-->
                        <div class="row">
                            <div class="col-md-1">
                                1
                            </div>
                            <div class="col-md-5">
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>EN</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <input class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');">
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                          <div class='controls margin-bottom-10'>
                                            <textarea class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');"></textarea>
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                               
                            </div>

                            <div class="col-md-5">
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>FR</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <input class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');">
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                          <div class='controls margin-bottom-10'>
                                            <textarea class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');"></textarea>
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                               
                            </div>
                        </div>
                        <!-- //row SELLING POINTS block-->

                        <!-- row SELLING POINTS block-->
                        <div class="row">
                            <div class="col-md-1">
                                2
                            </div>
                            <div class="col-md-5">
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>EN</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <input class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');">
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                          <div class='controls margin-bottom-10'>
                                            <textarea class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');"></textarea>
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                               
                            </div>

                            <div class="col-md-5">
                                <div class="row">
                                    <div class="col-md-2">
                                         <label class='control-label' for='product_name'>FR</label>
                                     </div>
                                     <div class="col-md-8">
                                         <div class='controls margin-bottom-10'>
                                         <input class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');">
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                          <div class='controls margin-bottom-10'>
                                            <textarea class='form-control' id='product_name' name="product_name" 
                                            type='text' onkeyup="$('.error_product_name').addClass('hide');"></textarea>
                                            <span class="color_red hide error_product_name" >Plese Enter Product name </span>
                                          </div>
                                     </div>
                                </div>
                               
                            </div>
                        </div>
                        <!-- //row SELLING POINTS block-->
                        
                        <div class="col-sm-8 col-sm-offset-0">
                                <div class='form-group col-sm-6 text-left'>
                                        <div class='controls'>
                                            <label class='control-label check-box-margin'>
                                                <input type="checkbox" name="" id=""> <span>PART 1 COMPLETED (25%)</span>
                                            </label>
                                        </div>    
                                    </div>
                                
                                <div class='form-group pull-right'>
                                    <div class='controls'>
                                        <input type="hidden" name="" id="" value="">
                                        <a class="btn btn-success" onclick="validate_admin_part_2()" >
                                            <i class='icon-save'></i> Save
                                        </a>
                                        <a href="" class="btn btn-default" >Cancel</a>
                                    </div>
                                </div>
                        </div> 
                        <div class="clearfix"></div>
                    </div>
                </div>
            </form>

                <!-- //part -2  -->
                
               <!-- part -3 start -->
             <form class="form" style="margin-bottom: 0;" method="post" action="#" accept-charset="UTF-8" id="marketting_part_3">
                 <input type="hidden" name="hdn_marketting_part_3" id="hdn_marketting_part_3" value="1">
                <div class="row">
                    <div class="col-sm-12 pull-left"> 
                        <span class="">
                            <h3 class="color_grey"> PART - 3 </h3>
                        </span>
                    </div>
                    <div class="clearfix"></div>
                    <div class="col-sm-12">
                        <h4> CHECKLIST PACKAGING </h4>
						<?php 
                            $i=1;
                            foreach($question_list_3 as $u_key) { ?>	
							<div class="row check-list">
								<div class="col-sm-6">
									<span class="check-list-number"><?php echo $i; ?></span>
									<label class='control-label'><?php echo $u_key->question; ?></label>
 								</div>
								<div class="col-sm-4">
									<div class='make-switch switch' data-off-label='&lt;i class="icon-remove"&gt;&lt;/i&gt;' data-on-label='&lt;i class="icon-ok"&gt;&lt;/i&gt;'>
									  <input type='hidden' name='check_list[<?php echo $u_key->id;?>]'>
									  <input type='checkbox' name='check_list[<?php echo $u_key->id;?>]'>
									</div>
								</div>
								<div class="clearfix"></div>
							</div>
                            <?php if($u_key->description_required=="yes"){ ?>
                                <div class="row check-list">
                                    <div class="col-sm-6">
                                        <label class='control-label'><?php echo $u_key->description_label; ?></label>
                                    </div>
          
                                    <div class="col-sm-4">
                                        <input type='hidden' name='txt_list[<?php echo $u_key->id;?>]' >
                                        <input class='form-control'  type='text' name='txt_list[<?php echo $u_key->id;?>]'>
                                    </div>

                                    <div class="clearfix"></div>
                                </div>
          
                            <?php } $i++; } ?>	
                    </div>

                    <div class="col-sm-6">

                    </div>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-6">
                                <input type="checkbox" name="marketting_step_3" id="marketting_step_3" > Part-3 Completed (34%)
                                <span class="color_red error_admin_part_3 hide">Please Check this checkbox for procced further.</span>
                            </div>
                            <div class="col-sm-6">
                                <div class='form-group pull-right'>
                                    <div class='controls'>
                                    <input type="hidden" name="" id="" value="">
                                    <!--
                                    <a class="btn btn-success" onclick="validate_admin_part_3()" >
                                        <i class='icon-save'></i> Save
                                    </a> -->
                                    <a class="btn btn-success" onclick="validate_marketting_part()" >
                                        <i class='icon-save'></i> Save
                                    </a>
                                    <a href="" class="btn btn-default" >Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </div>        
                        <div class="clearfix"></div>
                    </div>   
                </div>                                                
        </form>
               <!-- part 3 end -->
               
               <!-- part 4 start -->
               
        <form class="form" style="margin-bottom: 0;" method="post" action="#" accept-charset="UTF-8" id="admin_part_3">
           <div class="row">
               <div class="col-sm-12 pull-left"> 
                   <span class="">
                       <h3 class="color_grey"> PART - 4 </h3>
                   </span>
               </div>
               <div class="clearfix"></div>
               <div class="col-sm-12">
                   <h4> CHECKLIST PRODUCT IMAGE </h4>
                   <?php 
                       $k=1;
                       foreach($question_list_4 as $u_key) { ?>	
                       <div class="row check-list">
                           <div class="col-sm-6">
                               <span class="check-list-number"><?php echo $k; ?></span>
                               <label class='control-label'><?php echo $u_key->question; ?></label>
                           </div>
                           <div class="col-sm-4">
                               <div class='make-switch switch' data-off-label='&lt;i class="icon-remove"&gt;&lt;/i&gt;' data-on-label='&lt;i class="icon-ok"&gt;&lt;/i&gt;'>
                                 <input type='checkbox'>
                               </div>
                           </div>
                           <div class="clearfix"></div>
                       </div>
                   <?php $k++; } ?>	
               </div>

               <div class="col-sm-6">

               </div>
               <div class="col-sm-6">
                   <div class="row">
                       <div class="col-sm-6">
                           <input type="checkbox" name="complete_admin_part_1" id="complete_admin_part_1" > Part-4 Completed (80%)
                           <span class="color_red error_admin_part_3 hide">Please Check this checkbox for procced further.</span>
                       </div>
                       <div class="col-sm-6">
                           <div class='form-group pull-right'>
                               <div class='controls'>
                               <input type="hidden" name="" id="" value="">
                               <a class="btn btn-success" onclick="validate_admin_part_4()" >
                                   <i class='icon-save'></i> Save
                               </a>
                               <a href="" class="btn btn-default" >Cancel</a>
                               </div>
                           </div>
                       </div>
                   </div>        
                   <div class="clearfix"></div>
               </div>   
           </div>                                                
    </form>
               
               
               
               <!-- part 4 ends -->
            </div>
     </div>
</div>

<script type="text/javascript">
    
    function validate_marketting_part(){
        
      
        if($("#marketting_step_3").is(':checked')){
            var data = new FormData($("#marketting_part_3")[0]);
            $.ajax({
                url: '<?php echo base_url()."products/marketting_part_3"; ?>',
                processData: false, 
                type: 'post',
                dataType: 'json',
                data: data,
                contentType: false,
               success:function(response){
                    if(response.status=="success"){
                        $("#marketting_step_3").prop('disabled', true);
                    }
               }
            });
        }else{
        
            return false;
            $("#error_admin_part_3").removeClass("hide");
           
        } 
   }
   
</script>
