<div class='row' id='content-wrapper'>
	<div class='col-xs-12'>

		<div class='page-header page-header-with-buttons'>
			<h1 class='col-sm-12 pull-left'>
				<i class='icon-dashboard'></i>
				<span>Client Dashboard</span>
			</h1>


		</div>

		
	</div>
</div>