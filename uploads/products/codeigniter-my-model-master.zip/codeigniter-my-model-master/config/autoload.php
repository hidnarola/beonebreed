<?php

# Load the model class when the spark is loaded
$autoload['libraries'] = array('MY_Model');