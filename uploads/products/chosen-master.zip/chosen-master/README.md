# Chosen

Chosen is a library for making long, unwieldy select boxes more user friendly.

- MooTools support: 1.3+

For documentation, usage, and examples, see:  
http://julesjanssen.github.com/chosen

### Chosen Credits

- Built by [Harvest](http://www.getharvest.com/)
- Concept and development by [Patrick Filler](http://www.patrickfiller.com/)
- Design and CSS by [Matthew Lettini](http://matthewlettini.com/)
- Port to MooTools by [Jules Janssen](http://julesjanssen.github.com)