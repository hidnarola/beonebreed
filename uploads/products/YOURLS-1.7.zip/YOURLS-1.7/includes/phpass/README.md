phpass 
======

**phpass** (pronounced "pH pass") is a portable public domain password hashing framework

**phpass** can be found here : http://openwall.com/phpass/
