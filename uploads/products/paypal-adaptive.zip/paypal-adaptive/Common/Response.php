<?php
$url = $_SERVER["PHP_SELF"];
$url = preg_replace("/(.*)(adaptivepayments-sdk-php\/samples)(.*)/", "\\1\\2/index.php", $url);

?>
<table id="apiResponse">
	<tr>
		<td>Request:</td>
	</tr>
	<tr>
		<td><textarea rows="10" cols="100"><?php echo htmlspecialchars($service->getLastRequest());?></textarea>
		</td>
	</tr>
	<tr>
		<td>Response:</td>
	</tr>
	<tr>
		<td><textarea rows="10" cols="100"><?php echo htmlspecialchars($service->getLastResponse());?></textarea>
		</td>
	</tr>
</table>
<br>
<a href=<?php echo $url?>>Home</a>