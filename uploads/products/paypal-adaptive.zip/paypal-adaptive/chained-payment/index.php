<html>
    <head>
        <title>PayPal Marketplace</title>
        <link rel="stylesheet" type="text/css" href="css/style.css">
        <link rel="stylesheet" type="text/css" href="css/loadding.css">
        <link rel="stylesheet" type="text/css" href="css/popup-style.css">
        <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
    </head>
    <body>
        <div id="main">
            <center><h1>Paypal Adaptive Payments to build a Marketplace in PHP</h1></center>
            <div id="conatiner">
                <h2>Buy  '' jQuery Enter Key Form Submit ''  Script</h2>
                <hr/>
                <div id="first">
                    <img src="images/submit-form-on-enter-key-feature.png">
                    <div id="content">
                        <form action="proccess.php" method="POST">
                            <input type="hidden" name="id" value="<?php echo base64_encode(1); ?>">
                            <input type="submit" style="float:left;"class="fg-button yellow" value="Buy Now $50" name="submit" id="tatalamount">
                            <div id="preview"><a href="http://www.formget.com/tutorial/submit_form_on_enter_key_live_demo/form.html" target="_blank"class="fg-button teal">Live Preview</a></div>
                        </form>
                    </div>
                </div><div id="second">
                    <h4 id="author">Author</h4>
                    <img src="images/fugo.png"><p>Fugo of FormGet</p>
                    <hr class="type_1">
                    <h4 id="author">What will I get</h4>
                    <ul>
                        <li>Well Coded Script</li>
                        <li>Instant Product Access</li>
                        <li>All Future Updates</li>
                    </ul> 
                </div>
            </div>
        </div>
        <div class="cr"></div>
        <div id="footer">
            <span id="Note">Note : </span><span style="color:black;" > A chained payment is a payment from a sender that is indirectly split  among multiple receivers. <br/>Here if you buy a script,some part of payment will transfer to the web site admin and some part <br/>of payment to script author.</span>
            <img id="paypal_logo"src="images/secure-paypal-logo.jpg">
        </div>


        <div id="pop2" class="simplePopup">
            <div id="loader">
                <div id="circularG">
                    <div id="circularG_1" class="circularG">
                    </div>
                    <div id="circularG_2" class="circularG">
                    </div>
                    <div id="circularG_3" class="circularG">
                    </div>
                    <div id="circularG_4" class="circularG">
                    </div>
                    <div id="circularG_5" class="circularG">
                    </div>
                    <div id="circularG_6" class="circularG">
                    </div>
                    <div id="circularG_7" class="circularG">
                    </div>
                    <div id="circularG_8" class="circularG">
                    </div>
                </div>
            </div>
        </div>
        <script src="js/jquery.simplePopup.js" type="text/javascript"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                $('input#tatalamount').click(function() {
                    $('#pop2').simplePopup();
                });
            });
        </script>
    </body>
</html>
