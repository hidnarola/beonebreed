<?php
header('Location: chained-payment/index.php');
?>